
import React, { useEffect, useRef } from 'react';
import { TranscriptionEntry } from '../types';

interface TranscriptionPanelProps {
  history: TranscriptionEntry[];
  currentInput: string;
  currentOutput: string;
}

const TranscriptionPanel: React.FC<TranscriptionPanelProps> = ({ history, currentInput, currentOutput }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, currentInput, currentOutput]);

  return (
    <div 
      ref={scrollRef}
      className="flex-1 overflow-y-auto px-4 py-6 space-y-4 scroll-smooth"
    >
      {history.map((entry) => (
        <div 
          key={entry.id} 
          className={`flex ${entry.role === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div className={`max-w-[80%] rounded-2xl px-4 py-3 shadow-sm ${
            entry.role === 'user' 
              ? 'bg-rose-100 text-rose-800 rounded-tr-none' 
              : 'bg-sky-100 text-sky-800 rounded-tl-none'
          }`}>
            <p className="text-sm font-semibold mb-1 opacity-60 uppercase tracking-wider text-[10px]">
              {entry.role === 'user' ? 'You' : 'Sweet Scholar'}
            </p>
            <p className="text-md leading-relaxed">{entry.text}</p>
          </div>
        </div>
      ))}
      
      {currentInput && (
        <div className="flex justify-end">
          <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-rose-50 text-rose-400 rounded-tr-none border border-rose-100 animate-pulse">
            <p className="text-sm font-semibold mb-1 opacity-60 uppercase tracking-wider text-[10px]">You (Typing...)</p>
            <p className="text-md">{currentInput}</p>
          </div>
        </div>
      )}

      {currentOutput && (
        <div className="flex justify-start">
          <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-sky-50 text-sky-400 rounded-tl-none border border-sky-100 animate-pulse">
            <p className="text-sm font-semibold mb-1 opacity-60 uppercase tracking-wider text-[10px]">Sweet Scholar (Speaking...)</p>
            <p className="text-md">{currentOutput}</p>
          </div>
        </div>
      )}

      {history.length === 0 && !currentInput && !currentOutput && (
        <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 opacity-60 py-20">
          <div className="text-5xl mb-4">✨</div>
          <p className="text-lg font-medium">Click the button below to start your lesson!</p>
          <p className="text-sm">I'm here to help you learn anything in a kind and sweet way.</p>
        </div>
      )}
    </div>
  );
};

export default TranscriptionPanel;
