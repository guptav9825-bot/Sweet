
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
import { AppStatus, TranscriptionEntry } from './types';
import { decode, decodeAudioData, createPcmBlob } from './services/audioHelpers';
import AudioVisualizer from './components/AudioVisualizer';
import TranscriptionPanel from './components/TranscriptionPanel';

const SYSTEM_INSTRUCTION = `You are "Sweet Scholar", a world-class educational tutor known for being extremely kind, encouraging, and "sweet". 
Your voice is warm and supportive. 
You explain complex topics simply and patiently. 
Use gentle reinforcement like "Excellent question!", "You're doing wonderful!", and "Let's look at this together, dear student."
Keep your responses concise but helpful for a voice conversation.`;

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [history, setHistory] = useState<TranscriptionEntry[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentOutput, setCurrentOutput] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Audio Contexts & Nodes
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const inputAnalyzerRef = useRef<AnalyserNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const micStreamRef = useRef<MediaStream | null>(null);
  
  // Session Refs
  const sessionPromiseRef = useRef<Promise<any> | null>(null);

  const stopSession = useCallback(() => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => session.close());
      sessionPromiseRef.current = null;
    }

    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
      micStreamRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      inputAudioCtxRef.current.close();
      inputAudioCtxRef.current = null;
    }
    
    activeSourcesRef.current.forEach(source => source.stop());
    activeSourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    
    setStatus(AppStatus.IDLE);
  }, []);

  const startSession = async () => {
    try {
      setStatus(AppStatus.CONNECTING);
      setError(null);

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      
      // Setup Audio Contexts
      inputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      inputAnalyzerRef.current = inputAudioCtxRef.current.createAnalyser();
      inputAnalyzerRef.current.fftSize = 256;

      // Get Microphone Access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      // Connect to Gemini Live
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: SYSTEM_INSTRUCTION,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log('Gemini Live session opened');
            setStatus(AppStatus.ACTIVE);

            // Start streaming microphone input
            const source = inputAudioCtxRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioCtxRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              
              // Vital: Use session promise to prevent race condition
              sessionPromiseRef.current?.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(inputAnalyzerRef.current!);
            inputAnalyzerRef.current!.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioCtxRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Audio Transcription
            if (message.serverContent?.outputTranscription) {
              setCurrentOutput(prev => prev + message.serverContent!.outputTranscription!.text);
            } else if (message.serverContent?.inputTranscription) {
              setCurrentInput(prev => prev + message.serverContent!.inputTranscription!.text);
            }

            // Handle Audio Playback
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioCtxRef.current) {
              const audioBuffer = await decodeAudioData(
                decode(base64Audio),
                outputAudioCtxRef.current,
                24000,
                1
              );

              const source = outputAudioCtxRef.current.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputAudioCtxRef.current.destination);
              
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioCtxRef.current.currentTime);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              
              activeSourcesRef.current.add(source);
              source.onended = () => activeSourcesRef.current.delete(source);
            }

            // Handle Interruptions
            if (message.serverContent?.interrupted) {
              activeSourcesRef.current.forEach(s => s.stop());
              activeSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            // End of Turn
            if (message.serverContent?.turnComplete) {
              setHistory(prev => [
                ...prev,
                ...(currentInput ? [{ id: Date.now() + '-u', role: 'user' as const, text: currentInput, timestamp: Date.now() }] : []),
                ...(currentOutput ? [{ id: Date.now() + '-m', role: 'model' as const, text: currentOutput, timestamp: Date.now() }] : [])
              ]);
              setCurrentInput('');
              setCurrentOutput('');
            }
          },
          onerror: (e) => {
            console.error('Session error:', e);
            setError('Something went wrong with the connection. Please try again.');
            stopSession();
          },
          onclose: () => {
            console.log('Session closed');
            stopSession();
          }
        }
      });

      sessionPromiseRef.current = sessionPromise;

    } catch (err: any) {
      console.error('Initialization error:', err);
      setError(err.message || 'Failed to start session. Check your microphone permissions.');
      setStatus(AppStatus.ERROR);
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto glass shadow-2xl overflow-hidden">
      {/* Header */}
      <header className="p-6 bg-white border-b border-rose-100 flex items-center justify-between z-20">
        <div className="flex items-center space-x-3">
          <div className="bg-rose-400 text-white w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-lg shadow-rose-200">
            🍬
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800 leading-tight">Sweet Scholar</h1>
            <p className="text-xs font-medium text-slate-400">YOUR AI STUDY BUDDY</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${status === AppStatus.ACTIVE ? 'bg-green-400 animate-pulse' : 'bg-slate-300'}`} />
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{status}</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative bg-white/40">
        <AudioVisualizer 
          isActive={status === AppStatus.ACTIVE} 
          analyzer={inputAnalyzerRef.current || undefined} 
        />
        
        <TranscriptionPanel 
          history={history}
          currentInput={currentInput}
          currentOutput={currentOutput}
        />

        {error && (
          <div className="absolute top-4 left-4 right-4 bg-rose-50 border border-rose-200 text-rose-600 p-4 rounded-xl text-sm flex items-center shadow-lg z-30">
            <span className="mr-3 text-lg">⚠️</span>
            {error}
          </div>
        )}
      </main>

      {/* Footer Controls */}
      <footer className="p-8 bg-white/80 backdrop-blur-sm border-t border-rose-50 flex flex-col items-center space-y-4">
        {status === AppStatus.IDLE || status === AppStatus.ERROR ? (
          <button
            onClick={startSession}
            className="w-full max-w-xs group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-rose-500 font-pj rounded-2xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500 shadow-xl shadow-rose-200 hover:bg-rose-600 active:scale-95"
          >
            <span className="text-lg mr-2">🎙️</span>
            Start Teaching Me
          </button>
        ) : (
          <button
            onClick={stopSession}
            disabled={status === AppStatus.CONNECTING}
            className="w-full max-w-xs inline-flex items-center justify-center px-8 py-4 font-bold text-rose-500 transition-all duration-200 bg-white border-2 border-rose-200 rounded-2xl hover:bg-rose-50 active:scale-95 disabled:opacity-50"
          >
            {status === AppStatus.CONNECTING ? 'Connecting...' : 'End Lesson'}
          </button>
        )}
        <p className="text-xs text-slate-400 text-center font-medium max-w-xs px-4 leading-relaxed">
          Powered by Gemini 2.5 Native Audio. 
          <br/>Interact naturally with your voice.
        </p>
      </footer>
    </div>
  );
};

export default App;
